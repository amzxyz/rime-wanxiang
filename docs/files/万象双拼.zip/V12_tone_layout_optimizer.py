#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""V12：以二字词首选离散为第一目标的带调双拼 26 键布局优化器。

核心流程：
1. 把每个音节归一为“固定声母键 + 带调韵母 token”；
2. 对二字词按词频分层，词典序最小化首选损失；
3. 同一韵母 1~4 声硬分键，轻声默认自由；
4. 锁定首选质量后，再联合优化真实 QWERTY 热区、总负载和手感；
5. 最终结果始终从真实编码重新审计，不把求解器松弛变量当作结果。

复现当前 V12 时只需要三列 jichu（词、带调拼音、权重）。脚本内置当前方案
的 169 个 token 宇宙；--zi 仅用于补充/校验 token，不再是必需输入。
"""
from __future__ import annotations

import argparse
import csv
import gc
import hashlib
import json
import math
import random
import re
import time
import unicodedata
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

KEYS = tuple("abcdefghijklmnopqrstuvwxyz")

VERSION = "V12-clean-2026-10"

# 当前万象带调方案使用的完整 token 宇宙。
# 其中 m2、m4、uai0 在 27,398 个二字目标中没有出现，但部署规则仍需要保留。
DEFAULT_TOKEN_UNIVERSE = (
    'a0', 'a1', 'a2', 'a3', 'a4', 'ai0', 'ai1', 'ai2', 'ai3', 'ai4', 'an0', 'an1',
    'an2', 'an3', 'an4', 'ang0', 'ang1', 'ang2', 'ang3', 'ang4', 'ao0', 'ao1', 'ao2', 'ao3',
    'ao4', 'e0', 'e1', 'e2', 'e3', 'e4', 'ei0', 'ei1', 'ei2', 'ei3', 'ei4', 'en0',
    'en1', 'en2', 'en3', 'en4', 'eng0', 'eng1', 'eng2', 'eng3', 'eng4', 'er0', 'er2', 'er3',
    'er4', 'i0', 'i1', 'i2', 'i3', 'i4', 'ia0', 'ia1', 'ia2', 'ia3', 'ia4', 'ian0',
    'ian1', 'ian2', 'ian3', 'ian4', 'iang0', 'iang1', 'iang2', 'iang3', 'iang4', 'iao0', 'iao1', 'iao2',
    'iao3', 'iao4', 'ie0', 'ie1', 'ie2', 'ie3', 'ie4', 'in1', 'in2', 'in3', 'in4', 'ing0',
    'ing1', 'ing2', 'ing3', 'ing4', 'iong0', 'iong1', 'iong2', 'iong3', 'iong4', 'iu0', 'iu1', 'iu2',
    'iu3', 'iu4', 'm2', 'm4', 'o0', 'o1', 'o2', 'o3', 'o4', 'ong0', 'ong1', 'ong2',
    'ong3', 'ong4', 'ou0', 'ou1', 'ou2', 'ou3', 'ou4', 'u0', 'u1', 'u2', 'u3', 'u4',
    'ua0', 'ua1', 'ua2', 'ua3', 'ua4', 'uai0', 'uai1', 'uai2', 'uai3', 'uai4', 'uan0', 'uan1',
    'uan2', 'uan3', 'uan4', 'uang0', 'uang1', 'uang2', 'uang3', 'uang4', 'ui0', 'ui1', 'ui2', 'ui3',
    'ui4', 'un0', 'un1', 'un2', 'un3', 'un4', 'uo0', 'uo1', 'uo2', 'uo3', 'uo4', 'v0',
    'v1', 'v2', 'v3', 'v4', 've1', 've2', 've3', 've4', 'vn0', 'vn1', 'vn2', 'vn3',
    'vn4',
)
INITIAL_KEY = {"zh": "v", "ch": "i", "sh": "u"}
# 物理键模型只在“词首选质量”锁定后参与优化。
# KEY_HEAT_COST 越小越适合承载高频韵调；它不会越级牺牲高频二字词首选。
LEFT = set("qwertasdfgzxcvb")
RIGHT = set(KEYS) - LEFT
FINGER = {}
for _keys, _finger in (("qaz", "LP"), ("wsx", "LR"), ("edc", "LM"),
                       ("rftgvb", "LI"), ("yuhjnm", "RI"), ("ik", "RM"),
                       ("ol", "RR"), ("p", "RP")):
    for _key in _keys:
        FINGER[_key] = _finger
ROW, COL = {}, {}
for _i, _key in enumerate("qwertyuiop"):
    ROW[_key], COL[_key] = 0, _i
for _i, _key in enumerate("asdfghjkl"):
    ROW[_key], COL[_key] = 1, _i
for _i, _key in enumerate("zxcvbnm"):
    ROW[_key], COL[_key] = 2, _i
KEY_HEAT_COST = {
    "a": 1.12, "b": 1.18, "c": 1.02, "d": 0.82, "e": 0.92,
    "f": 0.68, "g": 0.92, "h": 0.92, "i": 0.90, "j": 0.68,
    "k": 0.82, "l": 0.98, "m": 1.18, "n": 0.98, "o": 1.10,
    "p": 1.48, "q": 1.58, "r": 0.98, "s": 0.94, "t": 1.08,
    "u": 1.02, "v": 1.08, "w": 1.15, "x": 1.22, "y": 1.08, "z": 1.58,
}
TONE_MARKS = {
    "ā": ("a", 1), "á": ("a", 2), "ǎ": ("a", 3), "à": ("a", 4),
    "ē": ("e", 1), "é": ("e", 2), "ě": ("e", 3), "è": ("e", 4),
    "ī": ("i", 1), "í": ("i", 2), "ǐ": ("i", 3), "ì": ("i", 4),
    "ō": ("o", 1), "ó": ("o", 2), "ǒ": ("o", 3), "ò": ("o", 4),
    "ū": ("u", 1), "ú": ("u", 2), "ǔ": ("u", 3), "ù": ("u", 4),
    "ǖ": ("v", 1), "ǘ": ("v", 2), "ǚ": ("v", 3), "ǜ": ("v", 4),
    "ü": ("v", 0), "ê": ("e", 0),
}
EPS = 1e-9


# -----------------------------------------------------------------------------
# 输入、拼音归一与基础数据结构
# -----------------------------------------------------------------------------


def parse_key_set(raw: str) -> Set[str]:
    keys = {x.strip().lower() for x in str(raw).replace("，", ",").split(",") if x.strip()}
    unknown = keys - set(KEYS)
    if unknown:
        raise ValueError(f"未知物理键：{','.join(sorted(unknown))}")
    return keys


def file_sha256(path: Optional[Path]) -> Optional[str]:
    """返回输入文件 SHA-256；用于记录可复现运行环境。"""
    if path is None or not path.is_file():
        return None
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


@dataclass(frozen=True)
class Syl:
    raw: str
    initial: str
    ikey: str
    final: str
    tone: int

    @property
    def token(self) -> str:
        return f"{self.final}{self.tone}"

    @property
    def group_id(self) -> str:
        return f"{self.initial}:{self.final}:{self.tone}"


@dataclass(frozen=True)
class Word:
    idx: int
    text: str
    pinyin: str
    weight: float
    syls: Tuple[Syl, ...]

    @property
    def group(self) -> Tuple[str, ...]:
        return tuple(s.group_id for s in self.syls)

    @property
    def ikeys(self) -> Tuple[str, ...]:
        return tuple(s.ikey for s in self.syls)

    @property
    def tokens(self) -> Tuple[str, ...]:
        return tuple(s.token for s in self.syls)


def strip_tone(raw: str) -> Tuple[str, int]:
    tone = 0
    chars: List[str] = []
    combining_tone = {"\u0304": 1, "\u0301": 2, "\u030c": 3, "\u0300": 4}
    for ch in unicodedata.normalize("NFD", raw.strip().lower()):
        if unicodedata.combining(ch):
            if ch == "\u0308" and chars and chars[-1] == "u":
                chars[-1] = "v"
            elif ch in combining_tone:
                tone = combining_tone[ch]
            continue
        if ch in TONE_MARKS:
            base, t = TONE_MARKS[ch]
            chars.append(base)
            tone = t
        elif ch in "012345":
            tone = int(ch) if ch in "1234" else 0
        else:
            chars.append("v" if ch == "ü" else ch)
    return "".join(chars), tone


def normalize_syllable(raw: str) -> Optional[Syl]:
    base, tone = strip_tone(raw)
    if not base:
        return None
    # 无调的成音节 n/ng/m 同样保留 0 调；轻声不暗中并入四声。
    if base == "n":
        return Syl(raw, "#n", "e", "en", tone)
    if base == "ng":
        return Syl(raw, "#ng", "e", "eng", tone)
    if base == "m":
        return Syl(raw, "#m", "e", "m", tone)
    yw = {
        "yi": ("y", "i"), "ya": ("y", "ia"), "ye": ("y", "ie"),
        "yao": ("y", "iao"), "you": ("y", "iu"), "yan": ("y", "ian"),
        "yin": ("y", "in"), "yang": ("y", "iang"), "ying": ("y", "ing"),
        "yong": ("y", "iong"), "yu": ("y", "v"), "yue": ("y", "ve"),
        "yuan": ("y", "uan"), "yun": ("y", "vn"),
        "wu": ("w", "u"), "wa": ("w", "ua"), "wo": ("w", "uo"),
        "wai": ("w", "uai"), "wei": ("w", "ui"), "wan": ("w", "uan"),
        "wen": ("w", "un"), "wang": ("w", "uang"), "weng": ("w", "eng"),
    }
    if base in yw:
        initial, final = yw[base]
        return Syl(raw, initial, initial, final, tone)
    initial, rest = "", base
    for c in ("zh", "ch", "sh"):
        if rest.startswith(c):
            initial, rest = c, rest[len(c):]
            break
    if not initial and rest and rest[0] in "bpmfdtnlgkhjqxrzcsyw":
        initial, rest = rest[0], rest[1:]
    if not rest:
        return None
    if initial in {"j", "q", "x"}:
        if rest == "u": rest = "v"
        elif rest == "ue": rest = "ve"
        elif rest == "un": rest = "vn"
    ikey = INITIAL_KEY.get(initial, initial or rest[0])
    legal = {"a","o","e","i","u","v","ai","ei","ao","ou","an","en","ang","eng","ong","er",
             "ia","ie","iao","iu","ian","in","iang","ing","iong","ua","uo","uai","ui",
             "uan","un","uang","ve","vn"}
    if ikey not in KEYS or rest not in legal:
        return None
    return Syl(raw, initial, ikey, rest, tone)


def read_words(path: Path) -> Tuple[List[Word], Dict[str, int], List[Tuple]]:
    rows: List[Word] = []
    stats = Counter()
    bad = []
    in_header = False
    for no, line in enumerate(path.read_text(encoding="utf-8-sig", errors="replace").splitlines(), 1):
        s = line.strip()
        if s == "---":
            in_header = True; stats["yaml_header_lines"] += 1; continue
        if in_header:
            stats["yaml_header_lines"] += 1
            if s == "...": in_header = False
            continue
        if not s or line.lstrip().startswith("#"):
            continue
        cols = line.rstrip("\r\n").split("\t")
        if len(cols) < 3:
            stats["bad_columns"] += 1; continue
        text, py = cols[0].strip(), "\t".join(cols[1:-1]).strip()
        try:
            weight = float(cols[-1].replace(",", ""))
        except ValueError:
            weight = -1
        if not text or not math.isfinite(weight) or weight < 0:
            stats["bad_weight"] += 1; continue
        syls = tuple(x for x in (normalize_syllable(x) for x in py.split()) if x is not None)
        if len(syls) != len(text):
            stats["bad_pinyin"] += 1
            if len(bad) < 20: bad.append((no, text, py, len(syls)))
            continue
        rows.append(Word(len(rows), text, py, weight, syls))
    return rows, dict(stats), bad


def source_first(words: Sequence[Word]) -> List[Word]:
    groups: Dict[Tuple[str, ...], List[Word]] = defaultdict(list)
    for w in words:
        groups[w.group].append(w)
    return sorted(
        (max(a, key=lambda x: (x.weight, x.text, x.pinyin)) for a in groups.values()),
        key=lambda x: (-x.weight, x.text, x.pinyin),
    )


def token_spelling(token: str) -> str:
    m = re.match(r"^(.*?)([0-4])$", token)
    if not m:
        return token
    fin, tone = m.group(1), int(m.group(2))
    fin = fin.replace("v", "ü")
    if tone == 0:
        return fin
    mark = {1: "\u0304", 2: "\u0301", 3: "\u030c", 4: "\u0300"}[tone]
    chars = list(m.group(1))
    if "a" in chars: i = chars.index("a")
    elif "e" in chars: i = chars.index("e")
    elif "o" in chars and "u" in chars and chars.index("o") < chars.index("u"): i = chars.index("o")
    else: i = next((j for j in range(len(chars) - 1, -1, -1) if chars[j] in "aeiouv"), 0)
    if chars[i] == "v":
        chars[i] = "u\u0308" + mark
    else:
        chars[i] += mark
    return unicodedata.normalize("NFC", "".join(chars).replace("v", "ü"))


def tone_edges(tokens: Iterable[str], policy: str) -> Set[Tuple[str, str]]:
    by_final: Dict[str, Dict[int, str]] = defaultdict(dict)
    for t in tokens:
        m = re.match(r"^(.*?)([0-4])$", t)
        if m: by_final[m.group(1)][int(m.group(2))] = t
    out: Set[Tuple[str, str]] = set()
    for d in by_final.values():
        vals = [d[t] for t in (1, 2, 3, 4) if t in d]
        for i, a in enumerate(vals):
            for b in vals[i + 1:]: out.add(tuple(sorted((a, b))))
        if policy == "distinct" and 0 in d:
            for b in d.values():
                if b != d[0]: out.add(tuple(sorted((d[0], b))))
    return out


def actual_code(word: Word, mapping: Dict[str, str]) -> str:
    return " ".join(s.ikey + mapping[s.token] for s in word.syls)


def _compact_algebra(mapping: Dict[str, str]) -> List[str]:
    lines = [
        "万象双拼:", "    __append:",
        "      - xform/Ⅺ//  # 用于 Lua 判断输入类型的标记",
        "      - xform/^sh/U/", "      - xform/^ch/I/", "      - xform/^zh/V/",
        r"      - xform/^([aoe])$/\u$1\u$1/",
        "      - xform/^(ā|á|ǎ|à)([ioun])$/a$1$2/",
        "      - xform/^(ō|ó|ǒ|ò)([ioun])$/o$1$2/",
        "      - xform/^(ē|é|ě|è)([ioun])$/e$1$2/",
        "      - xform/^(ā|á|ǎ|à)(ng)$/a$1$2/", "      - xform/^(ē|é|ě|è)(ng)$/e$1$2/",
        "      - xform/^(ā|á|ǎ|à)$/a$1/", "      - xform/^(ō|ó|ǒ|ò)$/o$1/",
        "      - xform/^(ē|é|ě|è)$/e$1/", "      - xform/^(ēr|ér|ěr|èr)$/e$1/",
        "      - xform/^([aoe])([a-z]+)$/$1$1$2/",
        "      - xform/^([jqxy])u/$1ü/", "      - xform/^([jqxy])ū/$1ǖ/",
        "      - xform/^([jqxy])ú/$1ǘ/", "      - xform/^([jqxy])ǔ/$1ǚ/",
        "      - xform/^([jqxy])ù/$1ǜ/", "      - xform/^([jqxy])ü(ān|án|ǎn|àn|an)$/$1u$2/",
        "      - xform/^n̄g$/eēng/", "      - xform/^ńg$/eéng/", "      - xform/^ňg$/eěng/",
        "      - xform/^ǹg$/eèng/", "      - xform/^ng$/eèng/",
        "      - xform/^n̄$/eēn/", "      - xform/^ń$/eén/", "      - xform/^ň$/eěn/",
        "      - xform/^ǹ$/eèn/", "      - xform/^n$/eèn/",
        "      - xform/^m̄$/em̄/", "      - xform/^ḿ$/eḿ/", "      - xform/^m̌$/em̌/", "      - xform/^m̀$/em̀/",
    ]
    grouped: Dict[str, List[str]] = defaultdict(list)
    seen: Dict[str, str] = {}
    for token, key in mapping.items():
        sp = token_spelling(token)
        if sp in seen and seen[sp] != token:
            raise RuntimeError(f"转写 spelling 冲突：{sp}: {seen[sp]} vs {token}")
        seen[sp] = token; grouped[key].append(sp)
    for key in KEYS:
        vals = sorted(set(grouped.get(key, ())), key=lambda s: (-len(s), s))
        if vals:
            pat = "|".join(re.escape(s).replace(r"\ü", "ü") for s in vals)
            lines.append(f"      - xform/^(.)(%s)$/$1{key.upper()}/" % pat)
    lines.append("      - xlit/ABCDEFGHIJKLMNOPQRSTUVWXYZ/abcdefghijklmnopqrstuvwxyz/")
    return lines



def atomic_json(path: Path, data):
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temp.replace(path)


def write_tsv(path: Path, header, rows):
    temp = path.with_name(path.name + ".tmp")
    with temp.open("w", encoding="utf-8", newline="") as f:
        wr = csv.writer(f, delimiter="\t"); wr.writerow(header); wr.writerows(rows)
    temp.replace(path)


def deduplicate(words):
    best = {}
    for w in words:
        key = (w.text, w.group)
        old = best.get(key)
        if old is None or w.weight > old.weight: best[key] = w
    return [Word(i, w.text, w.pinyin, w.weight, w.syls)
            for i, w in enumerate(best.values())]


def outranks(a, b, tie_policy):
    if a.text == b.text: return False  # 同一个候选的不同读音不互相抢位
    if a.weight > b.weight + EPS: return True
    return tie_policy == "split" and abs(a.weight - b.weight) <= EPS and (a.text, a.pinyin) < (b.text, b.pinyin)


# -----------------------------------------------------------------------------
# 二字词冲突矩阵与最终编码审计
# -----------------------------------------------------------------------------


def compile_conflicts(words, targets, hard_edges, tie_policy, out):
    by_initial = defaultdict(list)
    for w in words: by_initial[w.ikeys].append(w)
    clauses, forced = {}, {}
    raw_count = safe_count = 0
    path = out / "global_conflict_matrix.tsv"
    with path.open("w", encoding="utf-8", newline="") as f:
        wr = csv.writer(f, delimiter="\t")
        wr.writerow(["target", "target_pinyin", "weight", "competitor", "competitor_pinyin", "competitor_weight", "token_pairs", "constraint"])
        for no, t in enumerate(targets):
            owner = set(); permanent = []
            for c in by_initial[t.ikeys]:
                if not outranks(c, t, tie_policy): continue
                pairs = tuple(sorted({tuple(sorted((a, b))) for a, b in zip(t.tokens, c.tokens) if a != b}))
                raw_count += 1
                if any(e in hard_edges for e in pairs):
                    safe_count += 1
                    continue  # 同韵母四声分离已经保证这一对词不重码
                if not pairs: permanent.append(c)
                else: owner.add(pairs)
                wr.writerow([t.text, t.pinyin, t.weight, c.text, c.pinyin, c.weight,
                             " | ".join(f"{a}!={b}" for a, b in pairs),
                             "UNAVOIDABLE_WITH_FIXED_INITIALS" if not pairs else "SOFT_SEPARATION"])
            if permanent:
                forced[t.idx] = permanent
                clauses[t.idx] = ()
            else:
                singles = {es[0] for es in owner if len(es) == 1}
                # 对同一目标，一个单边要求已涵盖的 OR 要求不再重复建模。
                reduced = sorted(es for es in owner if len(es) == 1 or not any(e in singles for e in es))
                clauses[t.idx] = tuple(reduced)
            if no and no % 5000 == 0:
                print(f"[matrix] {no:,}/{len(targets):,} readings expanded", flush=True)
    return clauses, forced, {"raw_relations": raw_count, "already_separated_by_tone": safe_count,
                             "soft_clauses": sum(map(len, clauses.values())), "inherent_losses": len(forced)}


def audit(words, targets, mapping, tie_policy):
    buckets = defaultdict(list)
    for w in words: buckets[actual_code(w, mapping)].append(w)
    result = {}
    for t in targets:
        peers = [w for w in buckets[actual_code(t, mapping)] if w.text != t.text]
        higher = [w for w in peers if w.weight > t.weight + EPS]
        tied = [w for w in peers if abs(w.weight - t.weight) <= EPS]
        winners = [w for w in peers if outranks(w, t, tie_policy)]
        blocker = max(higher or winners or tied, key=lambda w: (w.weight, w.text, w.pinyin), default=None)
        status = "SECONDARY" if higher else ("TIED" if tied else "RETAINED")
        result[t.idx] = {"status": status, "loss": bool(winners), "blocker": blocker,
                         "code": actual_code(t, mapping), "candidate_count": len({w.text for w in buckets[actual_code(t, mapping)]}),
                         "actual_blockers": winners}
    return result


def validate_mapping(mapping, tokens, hard_edges, cap):
    if set(mapping) != set(tokens): raise ValueError("布局 token 集合不完整或混入旧 token")
    if any(k not in KEYS for k in mapping.values()): raise ValueError("布局含非 a-z 按键")
    if max(Counter(mapping.values()).values(), default=0) > cap: raise ValueError("布局超过每键容量")
    if any(mapping[a] == mapping[b] for a, b in hard_edges): raise ValueError("布局违反声调分键硬约束")


def initial_mapping(tokens, hard_edges, cap, seed):
    rng = random.Random(seed)
    neighbors = defaultdict(set)
    for a, b in hard_edges: neighbors[a].add(b); neighbors[b].add(a)
    order = sorted(tokens, key=lambda t: (-len(neighbors[t]), t))
    result = {}; loads = Counter()
    for t in order:
        excluded = {result[b] for b in neighbors[t] if b in result}
        available = [k for k in KEYS if loads[k] < cap and k not in excluded]
        if not available: return None
        rng.shuffle(available)
        k = min(available, key=lambda k: loads[k])
        result[t] = k; loads[k] += 1
    return result


# -----------------------------------------------------------------------------
# 物理键负载与手感指标
# -----------------------------------------------------------------------------


def _alternates(a: str, b: str) -> bool:
    return (a in LEFT and b in RIGHT) or (a in RIGHT and b in LEFT)


def _same_finger_move(a: str, b: str) -> bool:
    return a != b and FINGER.get(a) == FINGER.get(b)


def _far_same_row(a: str, b: str) -> bool:
    return (a != b and not _alternates(a, b) and ROW.get(a) == ROW.get(b)
            and abs(COL.get(a, 0) - COL.get(b, 0)) > 2)


def handfeel_usage(words: Sequence[Word]):
    """把每个带调 token 在真实声母键下的词频质量聚合起来。"""
    usage = Counter()
    token_mass = Counter()
    for word in words:
        for syl in word.syls:
            weight = max(1, int(round(word.weight)))
            usage[syl.token, syl.ikey] += weight
            token_mass[syl.token] += weight
    return usage, token_mass


def physical_load_masses(words: Sequence[Word]):
    """返回可变韵调负载与固定声母负载。

    每个音节实际包含“声母键 + 韵调键”两次物理击键。声母映射固定，
    因此不影响热区优化的相对值，但必须计入每个实体键的总负担均衡。
    """
    usage, token_mass = handfeel_usage(words)
    initial_mass = Counter()
    for (_, initial), weight in usage.items():
        initial_mass[initial] += int(weight)
    return token_mass, initial_mass


def handfeel_metrics(words: Sequence[Word], mapping: Dict[str, str]):
    usage, _ = handfeel_usage(words)
    mass = float(sum(usage.values()) or 1)
    alt = double = same_finger = far = heat = 0.0
    for (token, initial), weight in usage.items():
        key = mapping[token]
        alt += weight * int(_alternates(initial, key))
        double += weight * int(initial == key)
        same_finger += weight * int(_same_finger_move(initial, key))
        far += weight * int(_far_same_row(initial, key))
        heat += weight * KEY_HEAT_COST[key]
    return {
        "mass": int(mass),
        "alternation": alt / mass,
        "double": double / mass,
        "same_finger_move": same_finger / mass,
        "far_same_row_gt2": far / mass,
        "heat_cost": heat / mass,
        "alternation_mass": int(alt),
        "double_mass": int(double),
        "same_finger_mass": int(same_finger),
        "far_mass": int(far),
        "heat_mass": heat,
    }


def handfeel_objective_terms(model, tokens: Sequence[str], words: Sequence[Word]):
    """返回严格词典序手感目标，所有项都是整数线性目标。"""
    usage, token_mass = handfeel_usage(words)
    names = ("HAND_HEAT", "HAND_ALTERNATION", "HAND_DOUBLE",
             "HAND_SAME_FINGER", "HAND_FAR_ROW")
    terms = {name: [] for name in names}
    for token in tokens:
        for key_index, key in enumerate(KEYS):
            alt = double = same_finger = far = 0
            for (tok, initial), weight in usage.items():
                if tok != token:
                    continue
                alt += weight * int(_alternates(initial, key))
                double += weight * int(initial == key)
                same_finger += weight * int(_same_finger_move(initial, key))
                far += weight * int(_far_same_row(initial, key))
            heat = int(round(token_mass[token] * KEY_HEAT_COST[key] * 100))
            var = model.occupies[token, key_index]
            terms["HAND_ALTERNATION"].append((var, -int(alt)))
            terms["HAND_DOUBLE"].append((var, int(double)))
            terms["HAND_SAME_FINGER"].append((var, int(same_finger)))
            terms["HAND_FAR_ROW"].append((var, int(far)))
            terms["HAND_HEAT"].append((var, heat))
    return [(name, pairs) for name, pairs in terms.items()]


def bucket_balance_metrics(mapping: Dict[str, str], token_mass: Counter,
                           initial_mass: Optional[Counter] = None) -> Dict[str, float]:
    """审计实体键负载：固定声母质量 + 可变韵调桶质量。

    同时保留 final bucket 指标，便于区分“桶本身很重”与“落在本来就很忙的声母键”。
    """
    initial_mass = initial_mass or Counter()
    final_mass = {k: 0 for k in KEYS}
    counts = {k: 0 for k in KEYS}
    for token, key in mapping.items():
        final_mass[key] += int(token_mass.get(token, 0))
        counts[key] += 1
    total_load = {k: int(initial_mass.get(k, 0)) + final_mass[k] for k in KEYS}
    final_total = int(sum(final_mass.values()))
    initial_total = int(sum(int(initial_mass.get(k, 0)) for k in KEYS))
    grand_total = int(sum(total_load.values()))
    ideal_final = (final_total / len(KEYS)) if KEYS else 0.0
    ideal_total = (grand_total / len(KEYS)) if KEYS else 0.0

    def stats(values, ideal):
        max_v = max(values.values(), default=0)
        active = [v for v in values.values() if v > 0]
        variance = (sum((values[k] - ideal) ** 2 for k in KEYS) / len(KEYS)) if KEYS else 0.0
        stdev = math.sqrt(variance)
        return max_v, min(active, default=0), stdev, ((stdev / ideal) if ideal > 0 else 0.0)

    max_final, min_final, final_stdev, final_cv = stats(final_mass, ideal_final)
    max_total, min_total, total_stdev, total_cv = stats(total_load, ideal_total)
    final_l1_x26 = int(sum(abs(len(KEYS) * final_mass[k] - final_total) for k in KEYS))
    total_l1_x26 = int(sum(abs(len(KEYS) * total_load[k] - grand_total) for k in KEYS))
    return {
        "final_total_mass": final_total,
        "initial_total_mass": initial_total,
        "grand_total_load": grand_total,
        "ideal_final_mass": ideal_final,
        "ideal_total_load": ideal_total,
        "active_final_mass_keys": sum(1 for k in KEYS if final_mass[k] > 0),
        "max_final_mass": int(max_final),
        "min_active_final_mass": int(min_final),
        "max_final_over_ideal": (max_final / ideal_final) if ideal_final > 0 else 0.0,
        "final_l1_x26": final_l1_x26,
        "final_stdev": final_stdev,
        "final_cv": final_cv,
        "max_total_load": int(max_total),
        "min_active_total_load": int(min_total),
        "max_total_over_ideal": (max_total / ideal_total) if ideal_total > 0 else 0.0,
        "total_load_l1_x26": total_l1_x26,
        "total_load_stdev": total_stdev,
        "total_load_cv": total_cv,
        "max_token_count": max(counts.values(), default=0),
    }


def bucket_balance_cost(name: str, mapping: Dict[str, str], token_mass: Counter,
                        initial_mass: Optional[Counter] = None) -> int:
    m = bucket_balance_metrics(mapping, token_mass, initial_mass)
    if name == "KEY_MAX_TOTAL_LOAD":
        return int(m["max_total_load"])
    if name == "KEY_TOTAL_LOAD_L1_X26":
        return int(m["total_load_l1_x26"])
    raise KeyError(name)


def prepare_bucket_balance_terms(model, tokens: Sequence[str], token_mass: Counter,
                                 initial_mass: Optional[Counter] = None):
    """在 GlobalCpSat 上增加“声母固定负载 + 韵调可变负载”的实体键质量变量。"""
    initial_mass = initial_mass or Counter()
    final_total = int(sum(int(token_mass.get(t, 0)) for t in tokens))
    initial_total = int(sum(int(initial_mass.get(k, 0)) for k in KEYS))
    grand_total = final_total + initial_total
    final_mass_vars = []
    total_load_vars = []
    deviation_vars = []
    for ki, key in enumerate(KEYS):
        fv = model.model.new_int_var(0, max(0, final_total), f"final_weighted_mass_{key}")
        model.model.add(fv == sum(
            int(token_mass.get(t, 0)) * model.occupies[t, ki] for t in tokens
        ))
        final_mass_vars.append(fv)
        fixed = int(initial_mass.get(key, 0))
        tv = model.model.new_int_var(fixed, fixed + max(0, final_total), f"total_key_load_{key}")
        model.model.add(tv == fv + fixed)
        total_load_vars.append(tv)
        dv = model.model.new_int_var(0, max(0, len(KEYS) * grand_total), f"total_load_dev26_{key}")
        model.model.add(dv >= len(KEYS) * tv - grand_total)
        model.model.add(dv >= grand_total - len(KEYS) * tv)
        deviation_vars.append(dv)
    max_total_load = model.model.new_int_var(0, max(0, grand_total), "max_total_key_load")
    model.model.add_max_equality(max_total_load, total_load_vars)
    return {
        "final_total_mass": final_total,
        "initial_total_mass": initial_total,
        "grand_total": grand_total,
        "final_mass_vars": final_mass_vars,
        "total_load_vars": total_load_vars,
        "deviation_vars": deviation_vars,
        "max_total_load": max_total_load,
    }


def cold_critical_terms(model, words: Sequence[Word], args):
    """高频 token 落到冷键的加权质量。

    V12 把旧版的绝对禁止改成可求最优的目标：如果能做到 0 就会锁成 0；
    如果受其他硬约束影响做不到，也会得到数学上最小的冷键高频质量，而不会不可行崩溃。
    """
    _, mass = handfeel_usage(words)
    protected = critical_token_set(words, args)
    terms = []
    for token in sorted(protected):
        coef = int(mass.get(token, 0))
        if coef <= 0:
            continue
        for key in sorted(args.cold_key_set):
            terms.append((model.occupies[token, KEYS.index(key)], coef))
    return protected, terms


class HandfeelBucketCpSat:
    """在固定 token 桶成员后，把桶指派到真实 QWERTY 键。

    这一步只有最多 26 个桶，和 169 个 token 的首选模型完全分离；
    因而不会让物理键排列的对称性拖慢首选求解，也不会改变任何重码关系。
    """
    # 热区先锁定；后面的目标只能在不增加热区代价的前提下优化。
    NAMES = ("HAND_HEAT", "HAND_ALTERNATION", "HAND_DOUBLE",
             "HAND_SAME_FINGER", "HAND_FAR_ROW")

    def __init__(self, buckets, words, cold_keys=None, critical_tokens=None):
        from ortools.sat.python import cp_model
        self.cp = cp_model
        self.model = cp_model.CpModel()
        self.buckets = [tuple(sorted(x)) for x in buckets]
        usage, token_mass = handfeel_usage(words)
        self.token_mass = token_mass
        self.cold_keys = set(cold_keys or ())
        self.requested_guarded_tokens = set(critical_tokens or ())
        self.guarded_tokens = set(self.requested_guarded_tokens)

        # 冷键保护必须服从物理容量：如果 26 个桶都含高频 token，而 p/q
        # 两个冷键被完全禁用，则最多只能硬保护 24 个桶。旧版在这里直接
        # 抛异常，导致前面已经跑完数小时的首选结果全部丢失。V11/V12 改为
        # 容量感知降级：按“受保护 token 质量”优先，其次按整桶质量优先，
        # 只硬保护能放进非冷键的最重要桶；其余最低负载桶允许承担冷键。
        requested_guarded = [
            bi for bi, bucket in enumerate(self.buckets)
            if self.requested_guarded_tokens.intersection(bucket)
        ]
        max_guarded = max(0, len(KEYS) - len(self.cold_keys))

        def guard_rank(bi):
            bucket = self.buckets[bi]
            protected_mass = sum(
                self.token_mass[t] for t in bucket
                if t in self.requested_guarded_tokens
            )
            total_mass = sum(self.token_mass[t] for t in bucket)
            return (protected_mass, total_mass, tuple(bucket))

        ordered_guarded = sorted(requested_guarded, key=guard_rank, reverse=True)
        self.guarded_bucket_ids = set(ordered_guarded[:max_guarded])
        self.relaxed_bucket_ids = set(ordered_guarded[max_guarded:])
        self.relaxed_tokens = set(
            t for bi in self.relaxed_bucket_ids for t in self.buckets[bi]
            if t in self.requested_guarded_tokens
        )

        if self.relaxed_bucket_ids:
            print(
                f"[handfeel] 高频避键覆盖 {len(requested_guarded)} 个桶，但非冷键容量只有 {max_guarded}；"
                f"自动硬保护最高负载 {len(self.guarded_bucket_ids)} 桶，"
                f"放宽最低负载 {len(self.relaxed_bucket_ids)} 桶，保证布局可解。",
                flush=True,
            )

        self.x = {}
        self.terms = {name: [] for name in self.NAMES}
        for bi, bucket in enumerate(self.buckets):
            guarded = bi in self.guarded_bucket_ids
            for ki, key in enumerate(KEYS):
                var = self.model.new_bool_var(f"bucket_{bi}_at_{key}")
                self.x[bi, ki] = var
                if guarded and key in self.cold_keys:
                    self.model.add(var == 0)
                alt = double = same_finger = far = 0
                heat_mass = 0
                for token in bucket:
                    heat_mass += token_mass[token]
                    for (tok, initial), weight in usage.items():
                        if tok != token:
                            continue
                        alt += weight * int(_alternates(initial, key))
                        double += weight * int(initial == key)
                        same_finger += weight * int(_same_finger_move(initial, key))
                        far += weight * int(_far_same_row(initial, key))
                self.terms["HAND_ALTERNATION"].append((var, -int(alt)))
                self.terms["HAND_DOUBLE"].append((var, int(double)))
                self.terms["HAND_SAME_FINGER"].append((var, int(same_finger)))
                self.terms["HAND_FAR_ROW"].append((var, int(far)))
                self.terms["HAND_HEAT"].append(
                    (var, int(round(heat_mass * KEY_HEAT_COST[key] * 100))))
            self.model.add(sum(self.x[bi, ki] for ki in range(26)) == 1)
        for ki in range(26):
            self.model.add(sum(self.x[bi, ki] for bi in range(len(self.buckets))) <= 1)

    def solve_pass(self, name, seconds, workers):
        objective = self.terms[name]
        expr = sum(var * int(coef) for var, coef in objective)
        self.model.minimize(expr)
        solver = self.cp.CpSolver()
        solver.parameters.max_time_in_seconds = max(1.0, float(seconds))
        solver.parameters.num_search_workers = max(1, int(workers))
        solver.parameters.log_search_progress = False
        status = solver.solve(self.model)
        value = int(round(solver.objective_value)) if status in (self.cp.OPTIMAL, self.cp.FEASIBLE) else None
        return solver, status, solver.status_name(status), value, expr

    def mapping_from(self, solver):
        out = {}
        for bi, bucket in enumerate(self.buckets):
            ki = next(i for i in range(26) if solver.value(self.x[bi, i]))
            for token in bucket:
                out[token] = KEYS[ki]
        return out

    def hint(self, mapping):
        self.model.clear_hints()
        for bi, bucket in enumerate(self.buckets):
            key = mapping[bucket[0]]
            for ki, k in enumerate(KEYS):
                self.model.add_hint(self.x[bi, ki], int(key == k))

    def cost(self, name, mapping):
        return sum(int(self.terms[name][bi * len(KEYS) + KEYS.index(mapping[bucket[0]])][1])
                   for bi, bucket in enumerate(self.buckets))

    def feasible_start(self):
        """构造满足避键约束的桶置换，供超时回退和求解提示使用。"""
        guarded = [i for i in range(len(self.buckets)) if i in self.guarded_bucket_ids]
        plain = [i for i in range(len(self.buckets)) if i not in self.guarded_bucket_ids]
        remaining = set(KEYS)
        result = {}
        for ids in (guarded, plain):
            for bi in sorted(ids, key=lambda i: -sum(self.token_mass[t] for t in self.buckets[i])):
                available = remaining - self.cold_keys if bi in guarded else remaining
                key = min(available, key=lambda k: (KEY_HEAT_COST[k], k))
                remaining.remove(key)
                result.update((t, key) for t in self.buckets[bi])
        return result


def critical_token_set(words, args):
    _, mass = handfeel_usage(words)
    if args.critical_mass is not None:
        return {t for t, n in mass.items() if n >= args.critical_mass}
    ordered = sorted(mass, key=lambda t: (-mass[t], t))
    return set(ordered[:args.critical_top])


def optimize_physical_keys(base_mapping, words, args, started):
    buckets = defaultdict(list)
    for token, key in base_mapping.items():
        buckets[key].append(token)
    protected = critical_token_set(words, args)
    bm = HandfeelBucketCpSat(list(buckets.values()), words,
                            args.cold_key_set, protected)
    current = bm.feasible_start()
    logs = []
    completed = 0
    stop_reason = ""
    before = handfeel_metrics(words, base_mapping)
    print(f"[handfeel] 热区优先；允许热区调节={args.heat_slack:.1%}；"
          f"保护 token={len(protected)}，避开={','.join(sorted(args.cold_key_set)) or '无'}", flush=True)
    for name in bm.NAMES:
        remaining = args.global_sec - (time.time() - started)
        if remaining <= 0:
            stop_reason = "GLOBAL_TIME_LIMIT"
            break
        seconds = min(args.handfeel_seconds, remaining)
        bm.hint(current)
        solver, status, status_name, value, expr = bm.solve_pass(name, seconds, args.workers)
        incumbent = bm.cost(name, current)
        if status in (bm.cp.OPTIMAL, bm.cp.FEASIBLE):
            proposed = bm.mapping_from(solver)
            if value <= incumbent:
                current = proposed
            else:
                print(f"[handfeel] {name}: 新解比已知布局差，保留已知布局", flush=True)
            completed += 1
        else:
            stop_reason = f"{name}:{status_name}"
            print(f"[handfeel] {name}: 未返回新解；使用满足避键约束的现有布局", flush=True)
        bound = bm.cost(name, current)
        # 给热区一点可审计的空间，否则一个唯一最优置换会封死所有后续手感目标。
        limit = int(math.ceil(bound * (1 + args.heat_slack))) if name == "HAND_HEAT" else bound
        bm.model.add(expr <= limit)
        logs.append({"stage": name, "status": status_name, "objective": value,
                     "accepted_objective": bound, "locked_upper_bound": limit,
                     "seconds": seconds})
        atomic_json(args.out / "v12_handfeel_checkpoint.json",
                    {"mapping": current, "stages": logs,
                     "critical_tokens_requested": sorted(protected),
                     "critical_tokens_relaxed": sorted(bm.relaxed_tokens),
                     "relaxed_bucket_count": len(bm.relaxed_bucket_ids)})
        print(f"[handfeel] {name}: {status_name} accepted={bound} limit={limit}", flush=True)
    # 整桶注入式置换保留每一个 token 对的相等关系；逐词验证提供第二重保障。
    if canonicalize(base_mapping, sorted(base_mapping)) != canonicalize(current, sorted(current)):
        raise RuntimeError("物理重排改变了桶成员关系，拒绝导出")
    # 只验证容量允许硬保护的桶。被自动放宽的低负载桶允许进入冷键，
    # 这是为了在 26 桶/24 非冷键时保证物理布局必定存在。
    for bi in bm.guarded_bucket_ids:
        bucket = bm.buckets[bi]
        key = current[bucket[0]]
        if key in args.cold_key_set:
            raise RuntimeError(f"物理重排违反硬保护桶避键约束：{bucket[0]}")
    cold_spill = sorted(t for t in protected if current[t] in args.cold_key_set)
    if cold_spill:
        print(f"[handfeel] 容量降级后有 {len(cold_spill)} 个请求保护 token 落入冷键："
              f"{','.join(cold_spill[:12])}{'...' if len(cold_spill) > 12 else ''}", flush=True)
    after = handfeel_metrics(words, current)
    write_tsv(args.out / "handfeel_before_after.tsv", ["metric", "before", "after"],
              ([k, before[k], after[k]] for k in ("alternation", "double", "same_finger_move",
                                                 "far_same_row_gt2", "heat_cost")))
    print(f"[handfeel] 热区代价 {before['heat_cost']:.6f} -> {after['heat_cost']:.6f}；"
          "编码碰撞关系保持不变", flush=True)
    return current, logs, completed, stop_reason


def load_mapping(path):
    if path.is_dir():
        candidates = [path / "tone_final_to_key.tsv", path / "wanxiang_tone_layout.yaml"]
        path = next((p for p in candidates if p.is_file()), None)
        if path is None:
            raise ValueError("布局目录中没有 tone_final_to_key.tsv 或 wanxiang_tone_layout.yaml；请指定文件路径")
    if path.suffix.lower() == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        return data.get("mapping", data)
    if path.suffix.lower() in {"yaml", ".yaml", ".yml"}:
        data = {}
        for line in path.read_text(encoding="utf-8").splitlines():
            m = re.match(r'^\s+["\']?([a-z]+[0-4])["\']?:\s*["\']?([a-z])["\']?\s*$', line)
            if m: data[m[1]] = m[2]
        return data
    with path.open(encoding="utf-8-sig", newline="") as f:
        return {r["token"]: r["key"] for r in csv.DictReader(f, delimiter="\t")}


def read_decisions(path, targets):
    force, sacrifice = set(), set()
    if path is None: return force, sacrifice
    with path.open(encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            text = (row.get("text") or row.get("target") or "").strip()
            py = (row.get("pinyin") or row.get("target_pinyin") or "").strip()
            candidates = [w for w in targets if w.text == text and (not py or w.tokens == tuple(s.token for s in map(normalize_syllable, py.split()) if s))]
            if not candidates: raise ValueError(f"人工名单无法匹配：{text}/{py}")
            # 既可以使用三列 decisions.tsv，也可以直接编辑
            # unresolved_review.tsv 的 manual_decision 列后重新传入。
            op = (row.get("decision") or row.get("manual_decision") or "").strip().upper()
            if op == "FORCE_FIRST": force.update(w.idx for w in candidates)
            elif op.startswith("SACRIFICE"): sacrifice.update(w.idx for w in candidates)
            elif op.startswith("TRY") or op == "AUTO": pass  # TRY_BOTH 仍是全局软优化目标
            else: raise ValueError(f"不支持的人工决定：{op}；使用 AUTO/FORCE_FIRST/SACRIFICE_TARGET")
    if force & sacrifice: raise ValueError("同一词条不能同时 FORCE_FIRST 和 SACRIFICE_TARGET")
    return force, sacrifice


# -----------------------------------------------------------------------------
# CP-SAT：首选优先与联合细化
# -----------------------------------------------------------------------------


class GlobalCpSat:
    """CP-SAT 主模型：token→键、硬分键约束，以及每个目标词的首选损失位。

    loss=0 表示该目标词已与所有更高排名竞争词离散。最终状态会再次按真实编码
    审计，因此中间层尚未优化的 loss 松弛值不会被误当成最终结果。
    """
    def __init__(self, tokens, hard_edges, clauses, forced, force_first, cap, symmetry_break=True):
        try:
            from ortools.sat.python import cp_model
        except ImportError as exc:
            raise RuntimeError("请先安装：python -m pip install 'ortools>=9.10,<10'") from exc
        self.cp = cp_model; self.model = cp_model.CpModel()
        self.key = {t: self.model.new_int_var(0, 25, f"key_{t}") for t in tokens}
        self.occupies = {}
        for t in tokens:
            for k in range(26):
                b = self.model.new_bool_var(f"at_{t}_{k}")
                self.model.add(self.key[t] == k).only_enforce_if(b)
                self.model.add(self.key[t] != k).only_enforce_if(b.Not())
                self.occupies[t, k] = b
        self.loads = []
        for k in range(26):
            v = self.model.new_int_var(0, cap, f"load_{k}")
            self.model.add(v == sum(self.occupies[t, k] for t in tokens))
            self.loads.append(v)
        for a, b in sorted(hard_edges): self.model.add(self.key[a] != self.key[b])
        self.diff = {}
        needed = {e for arr in clauses.values() for es in arr for e in es}
        for a, b in sorted(needed):
            d = self.model.new_bool_var(f"diff_{a}_{b}")
            self.model.add(self.key[a] != self.key[b]).only_enforce_if(d)
            self.model.add(self.key[a] == self.key[b]).only_enforce_if(d.Not())
            self.diff[a, b] = d
        self.loss = {}
        for idx, arr in clauses.items():
            if not arr and idx not in forced: continue
            lost = self.model.new_bool_var(f"loss_{idx}"); self.loss[idx] = lost
            if idx in forced: self.model.add(lost == 1)
            else:
                for es in arr: self.model.add_bool_or([lost] + [self.diff[e] for e in es])
        for idx in sorted(force_first):
            if idx in self.loss:
                self.model.add(self.loss[idx] == 0)
        # 第一阶段只关心“谁与谁同桶”；固定第一个 token 的桶标签可消除大量对称解。
        if tokens and symmetry_break:
            self.model.add(self.key[tokens[0]] == 0)

    def hint(self, mapping, audited):
        self.model.clear_hints()
        for t, v in self.key.items(): self.model.add_hint(v, KEYS.index(mapping[t]))
        for (t, k), v in self.occupies.items(): self.model.add_hint(v, int(mapping[t] == KEYS[k]))
        for (a, b), v in self.diff.items(): self.model.add_hint(v, int(mapping[a] != mapping[b]))
        for idx, v in self.loss.items(): self.model.add_hint(v, int(audited[idx]["loss"]))
        loads = Counter(mapping.values())
        for k, v in enumerate(self.loads): self.model.add_hint(v, loads[KEYS[k]])

    def apply_hint(self, mapping, audit_rows):
        self.model.clear_hints()
        for t, var in self.key.items():
            self.model.add_hint(var, KEYS.index(mapping[t]))
        for (a, b), var in self.diff.items():
            self.model.add_hint(var, int(mapping[a] != mapping[b]))
        for idx, var in self.loss.items():
            self.model.add_hint(var, int(audit_rows.get(idx, {}).get("loss", False)))
        for k, var in enumerate(self.loads):
            self.model.add_hint(var, sum(1 for t in self.key if mapping[t] == KEYS[k]))

    def solve_pass(self, objective_terms, seconds, workers):
        # CP-SAT uses integer objectives. The caller adds an incumbent upper
        # bound before moving to the next priority tier.
        self.model.minimize(sum(var * int(coef) for var, coef in objective_terms))
        solver = self.cp.CpSolver()
        solver.parameters.max_time_in_seconds = max(1.0, float(seconds))
        solver.parameters.num_search_workers = max(1, int(workers))
        solver.parameters.log_search_progress = False
        solver.parameters.cp_model_presolve = True
        status = solver.solve(self.model)
        return solver, status, solver.status_name(status), (
            int(round(solver.objective_value))
            if status in (self.cp.OPTIMAL, self.cp.FEASIBLE) else None
        )

    def mapping_from(self, solver):
        return {t: KEYS[solver.value(v)] for t, v in self.key.items()}


def canonicalize(mapping, tokens):
    # First-use color labeling, consistent with key[tokens[0]] == 0.
    labels = {}; out = {}
    for t in tokens:
        k = mapping[t]
        if k not in labels: labels[k] = KEYS[len(labels)]
        out[t] = labels[k]
    return out


def priority_stages(args, targets, sacrifice, loss_vars):
    active = [w for w in targets if w.idx not in sacrifice and w.idx in loss_vars]
    if args.priority_mode == "weighted":
        return [("ALL_WEIGHT", {w.idx: max(1, int(round(w.weight * args.weight_scale))) for w in active})]
    thresholds = sorted({float(x) for x in args.tier_thresholds.split(",")}, reverse=True)
    if any(not math.isfinite(t) or t < 0 for t in thresholds): raise ValueError("层级阈值必须为非负有限数字")
    if not thresholds or thresholds[-1] != 0: thresholds.append(0)
    stages = []
    for n, lo in enumerate(thresholds):
        hi = thresholds[n - 1] if n else math.inf
        items = [w for w in active if lo <= w.weight < hi]
        if not items: continue
        label = f"[{lo:g},{hi:g})"
        stages.append((label + "_COUNT", {w.idx: 1 for w in items}))
        stages.append((label + "_WEIGHT", {w.idx: max(1, int(round(w.weight * args.weight_scale))) for w in items}))
    return stages


def objective_cost(coeff, audited):
    return sum(c * int(audited[i]["loss"]) for i, c in coeff.items())



def refinement_objective_cost(name, mapping, words, args, token_mass):
    if name in {"KEY_MAX_TOTAL_LOAD", "KEY_TOTAL_LOAD_L1_X26"}:
        _, initial_mass = physical_load_masses(words)
        return bucket_balance_cost(name, mapping, token_mass, initial_mass)
    if name == "COLD_CRITICAL_MASS":
        protected = critical_token_set(words, args)
        return int(sum(
            int(token_mass.get(t, 0)) for t in protected
            if mapping.get(t) in args.cold_key_set
        ))
    metrics = handfeel_metrics(words, mapping)
    if name == "HAND_HEAT":
        return int(sum(
            int(round(int(token_mass.get(t, 0)) * KEY_HEAT_COST[mapping[t]] * 100))
            for t in mapping
        ))
    if name == "HAND_ALTERNATION":
        return -int(metrics["alternation_mass"])
    if name == "HAND_DOUBLE":
        return int(metrics["double_mass"])
    if name == "HAND_SAME_FINGER":
        return int(metrics["same_finger_mass"])
    if name == "HAND_FAR_ROW":
        return int(metrics["far_mass"])
    raise KeyError(name)


def optimize_global_refinement(primary_mapping, tokens, words, targets, hard_edges,
                               clauses, forced, force_first, stages, args, started):
    """在所有首选层都锁定后，重新开放桶成员与物理键标签，做联合二次优化。

    第一模型用抽象标签消除 26! 对称；第二模型取消该对称约束，但把第一模型
    每个首选层的实际上界全部变成硬约束。因此这里可以同时改变“谁和谁同桶”
    以及“桶落到哪个 QWERTY 键”，却不能让任何首选优先层退化。
    """
    token_mass, initial_mass = physical_load_masses(words)
    ref = GlobalCpSat(tokens, hard_edges, clauses, forced, force_first,
                      args.max_per_key, symmetry_break=False)
    primary_audit = audit(words, targets, primary_mapping, args.tie_policy)
    priority_bounds = {}
    for label, coeff in stages:
        bound = int(objective_cost(coeff, primary_audit))
        expr = sum(int(c) * ref.loss[i] for i, c in coeff.items())
        ref.model.add(expr <= bound)
        priority_bounds[label] = bound

    # 当前首选布局是第二模型的确定可行起点。
    ref.apply_hint(primary_mapping, primary_audit)
    balance = prepare_bucket_balance_terms(ref, tokens, token_mass, initial_mass)
    protected, cold_terms = cold_critical_terms(ref, words, args)
    hand_terms = dict(handfeel_objective_terms(ref, tokens, words))

    # 物理标签一旦开放，先用真实热区代价打破 26 个键的大规模标签对称：
    # usage_weight × KEY_HEAT_COST 是第一物理目标。随后只在热区允许的 slack 内
    # 压低最重按键，再照顾高频 token 避冷键和其它手感。最后 L1 只使用剩余自由度。
    # 这样不会为了“数学上绝对平均”反而把高频负担从 f/j/d/k 摊到 q/p。
    objectives = [("HAND_HEAT", hand_terms["HAND_HEAT"], args.handfeel_seconds),
                  ("KEY_MAX_TOTAL_LOAD", [(balance["max_total_load"], 1)], args.balance_seconds)]
    if cold_terms:
        objectives.append(("COLD_CRITICAL_MASS", cold_terms, args.balance_seconds))
    for name in ("HAND_ALTERNATION", "HAND_DOUBLE",
                 "HAND_SAME_FINGER", "HAND_FAR_ROW"):
        objectives.append((name, hand_terms[name], args.handfeel_seconds))
    objectives.append(("KEY_TOTAL_LOAD_L1_X26",
                       [(v, 1) for v in balance["deviation_vars"]], args.balance_seconds))

    current_mapping = dict(primary_mapping)
    logs = []
    completed = 0
    stop_reason = ""

    def priority_ok(mapping):
        rows = audit(words, targets, mapping, args.tie_policy)
        bad = []
        for label, coeff in stages:
            actual = int(objective_cost(coeff, rows))
            if actual > priority_bounds[label]:
                bad.append((label, actual, priority_bounds[label]))
        if bad:
            raise RuntimeError(f"联合优化违反首选锁定：{bad[:5]}")
        return rows

    before_balance = bucket_balance_metrics(current_mapping, token_mass, initial_mass)
    for name, terms, requested_seconds in objectives:
        remaining = args.global_sec - (time.time() - started)
        if remaining <= 0:
            stop_reason = "GLOBAL_TIME_LIMIT"
            break
        seconds = min(float(requested_seconds), max(1.0, remaining))
        incumbent_value = refinement_objective_cost(
            name, current_mapping, words, args, token_mass)
        current_audit = priority_ok(current_mapping)
        ref.apply_hint(current_mapping, current_audit)
        solver, status, status_name, value = ref.solve_pass(terms, seconds, args.workers)
        accepted_value = incumbent_value
        candidate_value = None
        if status in (ref.cp.OPTIMAL, ref.cp.FEASIBLE):
            proposed = ref.mapping_from(solver)  # 此处 a-z 已是真实物理键，禁止 canonicalize
            priority_ok(proposed)
            candidate_value = refinement_objective_cost(
                name, proposed, words, args, token_mass)
            if candidate_value <= incumbent_value:
                current_mapping = proposed
                accepted_value = candidate_value
            else:
                print(f"[refine] {name}: 新解={candidate_value} 劣于已有={incumbent_value}，保留已有布局", flush=True)
            completed += 1
        else:
            stop_reason = f"{name}:{status_name}"
            print(f"[refine] {name}: {status_name}；保留当前可行布局={incumbent_value}", flush=True)

        expr = sum(var * int(coef) for var, coef in terms)
        if name == "KEY_MAX_TOTAL_LOAD":
            limit = int(math.ceil(accepted_value * (1 + args.bucket_max_slack)))
        elif name == "HAND_HEAT":
            limit = int(math.ceil(accepted_value * (1 + args.heat_slack)))
        else:
            limit = int(accepted_value)
        ref.model.add(expr <= limit)
        log = {
            "stage": name,
            "status": status_name,
            "objective": value,
            "candidate_objective": candidate_value,
            "incumbent_objective": incumbent_value,
            "accepted_objective": accepted_value,
            "locked_upper_bound": limit,
            "seconds": seconds,
        }
        logs.append(log)
        atomic_json(
            args.out / "v12_global_refine_checkpoint.json",
            {
                "mapping": current_mapping,
                "stage": name,
                "stages": logs,
                "priority_bounds": priority_bounds,
                "bucket_balance": bucket_balance_metrics(current_mapping, token_mass, initial_mass),
                "critical_tokens": sorted(protected),
                "elapsed_sec": time.time() - started,
            },
        )
        print(f"[refine] {name}: {status_name} accepted={accepted_value} limit={limit}", flush=True)

    after_balance = bucket_balance_metrics(current_mapping, token_mass, initial_mass)
    priority_ok(current_mapping)
    write_tsv(args.out / "global_refinement.tsv",
              ["stage", "status", "objective", "candidate_objective",
               "incumbent_objective", "accepted_objective", "locked_upper_bound", "seconds"],
              ([x.get("stage", ""), x.get("status", ""), x.get("objective", ""),
                x.get("candidate_objective", ""), x.get("incumbent_objective", ""),
                x.get("accepted_objective", ""), x.get("locked_upper_bound", ""),
                x.get("seconds", "")] for x in logs))
    write_tsv(args.out / "bucket_balance_before_after.tsv",
              ["metric", "before", "after"],
              ([k, before_balance.get(k, ""), after_balance.get(k, "")]
               for k in ("active_final_mass_keys", "max_final_mass", "ideal_final_mass",
                         "max_final_over_ideal", "final_cv", "max_total_load", "ideal_total_load",
                         "max_total_over_ideal", "total_load_l1_x26", "total_load_cv",
                         "max_token_count")))
    return (current_mapping, logs, completed, len(objectives), stop_reason,
            priority_bounds, before_balance, after_balance)


# -----------------------------------------------------------------------------
# 输出、Rime algebra 与审计文件
# -----------------------------------------------------------------------------


def build_algebra(mapping, template):
    if template is None: return _compact_algebra(mapping)
    text = template.read_text(encoding="utf-8")
    marker = "{{TOKEN_KEY_RULES}}"
    if text.count(marker) != 1: raise ValueError("转写模板必须且只能包含一个 {{TOKEN_KEY_RULES}} 占位符")
    grouped = defaultdict(list)
    for t, k in mapping.items(): grouped[k].append(token_spelling(t))
    rules = []
    for k in KEYS:
        vals = sorted(set(grouped[k]), key=lambda s: (-len(s), s))
        if vals: rules.append(f"      - xform/^(.)({'|'.join(re.escape(s) for s in vals)})$/$1{k.upper()}/")
    # Marker occupies its own line; all other template bytes are preserved.
    for line in text.splitlines():
        if marker in line and line.strip() != marker:
            raise ValueError("{{TOKEN_KEY_RULES}} 应独占一行")
    return text.replace(next(line for line in text.splitlines() if marker in line), "\n".join(rules)).splitlines()


def simulate_algebra(raw, rules):
    value = unicodedata.normalize("NFC", raw.strip().lower())
    for line in rules:
        body = line.strip()
        if not body.startswith("- "): continue
        body = body[2:].split("  #", 1)[0].strip()
        if body.startswith("xform/"):
            parts = body[len("xform/"):].split("/")
            if len(parts) < 3: raise ValueError(f"无法验证转写规则：{line}")
            pat, replacement = parts[:2]
            def repl(m):
                def group(g):
                    val = m.group(int(g.group(2))) or ""
                    return val.upper() if g.group(1) else val
                r = re.sub(r'(\\u)?\$(\d+)', group, replacement)
                return r
            value = re.sub(pat, repl, value)
        elif body.startswith("xlit/"):
            parts = body[len("xlit/"):].split("/")
            value = value.translate(str.maketrans(parts[0], parts[1]))
        else:
            raise ValueError("验证器只支持 xform/xlit；自定义复杂模板可用 --skip-algebra-check 并自行部署验证")
    return value


def export_outputs(out, mapping, words, targets, hard_edges, cap, meta, args, zi,
                   force_first, sacrificed, handfeel_applied=False):
    tokens = sorted(mapping)
    validate_mapping(mapping, tokens, hard_edges, cap)
    rows = audit(words, targets, mapping, args.tie_policy)
    if any(rows[i]["loss"] for i in force_first): raise RuntimeError("导出失败：布局违反 FORCE_FIRST")
    usage_count = Counter(s.token for w in words for s in w.syls)
    usage_weight, initial_weight = physical_load_masses(words)
    motor = handfeel_metrics(words, mapping)
    balance = bucket_balance_metrics(mapping, usage_weight, initial_weight)
    write_tsv(out / "tone_final_to_key.tsv", ["token", "key", "spelling", "usage_count", "usage_weight"],
              ([t, mapping[t], token_spelling(t), usage_count[t], usage_weight[t]] for t in tokens))
    bykey = defaultdict(list)
    for t, k in mapping.items(): bykey[k].append(t)
    grand_weight = int(sum(usage_weight.values()) + sum(initial_weight.values()) or 1)
    bucket_rows = []
    for k in KEYS:
        arr = sorted(bykey.get(k, ()))
        final_weight = int(sum(usage_weight[t] for t in arr))
        init_weight = int(initial_weight.get(k, 0))
        total_load = init_weight + final_weight
        bucket_rows.append([
            k, len(arr), init_weight, final_weight, total_load, total_load / grand_weight,
            KEY_HEAT_COST[k], final_weight * KEY_HEAT_COST[k],
            total_load * KEY_HEAT_COST[k], " ".join(arr),
        ])
    write_tsv(out / "bucket_load_summary.tsv",
              ["key", "token_count", "initial_usage_weight", "final_usage_weight",
               "total_key_load", "total_load_share", "key_heat_cost", "final_weighted_heat",
               "total_weighted_heat", "tokens"], bucket_rows)
    yl = ["mapping:"] + [f'  "{t}": "{mapping[t]}"' for t in tokens] + ["keys:"]
    yl += [f"  {k}: [{', '.join(json.dumps(t, ensure_ascii=False) for t in sorted(bykey[k]))}]" for k in KEYS]
    (out / "wanxiang_tone_layout.yaml").write_text("\n".join(yl) + "\n", encoding="utf-8")
    algebra = build_algebra(mapping, args.algebra_template)
    # 这里只做静态覆盖检查。Rime 的 xform 替换语义包含 \u 等扩展，
    # 不能用 Python re.sub 冒充运行时；真正的运行时覆盖仍由用户的 Rime
    # schema 验证。静态检查只确认每个 token spelling 已被绑定到某个键规则。
    algebra_text = "\n".join(algebra)
    missing = [[t, token_spelling(t), mapping[t]] for t in sorted(mapping)
               if token_spelling(t) not in algebra_text]
    write_tsv(out / "algebra_validation.tsv", ["token", "spelling", "expected_key"], missing)
    name = "wanxiang_tone_algebra.UNVERIFIED.yaml" if missing else "wanxiang_tone_algebra.clean.yaml"
    (out / name).write_text("\n".join(algebra) + "\n", encoding="utf-8")
    other = out / ("wanxiang_tone_algebra.clean.yaml" if missing else "wanxiang_tone_algebra.UNVERIFIED.yaml")
    if other.exists(): other.unlink()
    ordered = sorted(targets, key=lambda w: (-w.weight, w.text, w.pinyin))
    header = ["text", "pinyin", "weight", "status", "actual_code", "optimization_loss", "manual_decision",
              "competitor", "competitor_pinyin", "competitor_weight", "candidate_count", "different_tokens"]
    def output_row(w):
        r = rows[w.idx]; c = r["blocker"]
        decision = "FORCE_FIRST" if w.idx in force_first else ("SACRIFICE_TARGET" if w.idx in sacrificed else "AUTO")
        diffs = " | ".join(f"{a}={mapping[a]} vs {b}={mapping[b]}" for a, b in zip(w.tokens, c.tokens) if a != b) if c else ""
        return [w.text, w.pinyin, w.weight, r["status"], r["code"], int(r["loss"]), decision,
                c.text if c else "", c.pinyin if c else "", c.weight if c else "", r["candidate_count"], diffs]
    write_tsv(out / "source_first_global_audit.tsv", header, (output_row(w) for w in ordered))
    write_tsv(out / "unresolved_review.tsv", header, (output_row(w) for w in ordered if rows[w.idx]["status"] != "RETAINED"))
    write_tsv(out / "decisions_template.tsv", ["text", "pinyin", "decision"],
              ([w.text, w.pinyin, "AUTO"] for w in ordered if rows[w.idx]["status"] != "RETAINED"))
    families = defaultdict(dict)
    for t, k in mapping.items(): families[t[:-1]][int(t[-1])] = k
    write_tsv(out / "tone_distinct_audit.tsv", ["final", "tone1", "tone2", "tone3", "tone4", "neutral0", "policy", "status"],
              ([f] + [d.get(i, "") for i in [1, 2, 3, 4, 0]] + [args.neutral_policy, "PASS"] for f, d in sorted(families.items())))
    write_tsv(out / "handfeel_summary.tsv", ["metric", "value", "definition"], [
        ["alternation", motor["alternation"], "声母键与韵母键左右手相反的词频质量比例"],
        ["double", motor["double"], "声母键与韵母键相同的词频质量比例"],
        ["same_finger_move", motor["same_finger_move"], "同指不同键的词频质量比例"],
        ["far_same_row_gt2", motor["far_same_row_gt2"], "同手同排且横向跨度大于 2 的词频质量比例"],
        ["heat_cost", motor["heat_cost"], "按 QWERTY 键位热区代价加权的平均值；q/p 高、d/f/j/k 低"],
    ])
    counts = Counter(r["status"] for r in rows.values())
    meta = dict(meta)
    meta.update({"actual_retained": counts["RETAINED"], "actual_tied": counts["TIED"], "actual_secondary": counts["SECONDARY"],
                 "actual_objective_losses": sum(r["loss"] for r in rows.values()),
                 "max_key_load": max(Counter(mapping.values()).values(), default=0),
                 "handfeel_enabled": not args.no_handfeel,
                 "handfeel_applied": bool(handfeel_applied),
                 "handfeel_metrics": motor,
                 "bucket_balance": balance,
                 "algebra_lines": len(algebra), "algebra_validation": "SKIPPED" if args.skip_algebra_check else ("FAIL" if missing else "PASS"),
                 "algebra_mismatches": len(missing), "manual_force_count": len(force_first), "manual_sacrifice_count": len(sacrificed)})
    atomic_json(out / "v12_solver_summary.json", meta)
    report = ["# V12 二字词首选离散 + 物理键联合优化", "", f"目标二字读音词条：{len(targets):,}；token：{len(tokens)}。",
              f"实际首选 {counts['RETAINED']:,}；并列 {counts['TIED']:,}；次选 {counts['SECONDARY']:,}。", "",
              "核心目标是二字词首选离散：声调信息首先用于减少高频二字词的首选重码。",
              "所有目标同时建模；没有 NOT_REACHED 状态。次选从最终编码与竞争词重新计算。",
              "同一词条（词+读音）无论被多少词压住，仅计一次目标损失。",
              "FORCE_FIRST 是硬约束；SACRIFICE_TARGET 只免除其优化奖励，不删词、不保证它一定变次选。",
              "损失位是求解松弛变量；最终统计以实际编码审计为准。", "",
              f"证明状态：{meta.get('proof_status', 'UNPROVEN')}。只有所有阶段为 OPTIMAL 才能称所选层级目标已证最优。",
              "FEASIBLE 表示找到布局但未证明最优；UNKNOWN 不表示某个词不可行。",
              f"转写验证：{meta['algebra_validation']}；异常 {len(missing)}；规则 {len(algebra)} 行。", "",
              f"实体键总负载（固定声母+可变韵调）：最大 {balance['max_total_load']:,}，理论均值 {balance['ideal_total_load']:.1f}，"
              f"最大/均值 {balance['max_total_over_ideal']:.3f}，CV={balance['total_load_cv']:.4f}；"
              f"单看韵调桶最大质量 {balance['max_final_mass']:,}。详见 bucket_load_summary.tsv。",
              "V12 联合细化顺序：加权热区代价(usage_weight×KEY_HEAT_COST，留 heat slack) > 最大按键负载(留 balance slack) > 冷键高频质量 > 左右手互击 > 同键双击 > 同指 > 跨度 > 最终负载 L1。",
              f"高频 token 避开实体键：{','.join(sorted(args.cold_key_set)) or '无'}；"
              f"保护数量：{args.critical_top if args.critical_mass is None else 'mass>='+str(args.critical_mass)}；"
              f"热区调节空间：{args.heat_slack:.1%}；最大总负载调节空间：{args.bucket_max_slack:.1%}。详见 handfeel_summary.tsv。", "",
              "`unresolved_review.tsv` 列出最终次选/并列及实际压位词；修改 decisions_template.tsv 后用 --decision-file 重算。",
              "轻声 free：0 调有独立变量，可以与同韵母其它声调同键；distinct：0 调也硬分键。",
              "影子词库不会进入优化；如果未来实际合并，权重较高或同分排序仍可能改变首选，以 shadow_target_audit.tsv 检查。",
              f"版本：{VERSION}；输入 SHA-256 已写入 v12_matrix_summary.json。"]
    (out / "report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    if missing: print(f"[algebra] {len(missing)} 个 token 未覆盖；查看 algebra_validation.tsv，规则已标为 UNVERIFIED", flush=True)
    return rows, meta


def write_shadow_audit(path, shadow, mapping, targets, tie_policy):
    buckets = defaultdict(list)
    for w in targets: buckets[actual_code(w, mapping)].append(w)
    rows = []
    for w in shadow:
        if not all(s.token in mapping for s in w.syls):
            rows.append([w.text, w.pinyin, w.weight, "", "TOKEN_NOT_IN_LAYOUT", ""]); continue
        code = actual_code(w, mapping)
        peers = [x for x in buckets.get(code, ()) if x.text != w.text]
        comp = max(peers, key=lambda x: (x.weight, x.text, x.pinyin), default=None)
        status = "SHADOW_COLLIDES_WITH_TARGET" if comp else "SHADOW_ONLY"
        rows.append([w.text, w.pinyin, w.weight, code, status, comp.text if comp else ""])
    write_tsv(path, ["text", "pinyin", "weight", "actual_code", "status", "target_competitor"], rows)


# -----------------------------------------------------------------------------
# CLI
# -----------------------------------------------------------------------------


def main():
    here = Path(__file__).resolve().parent
    ap = argparse.ArgumentParser(description="V12：二字词首选优先的带调双拼 26 键 CP-SAT 布局优化器")
    ap.add_argument("--zi", type=Path, default=None,
                    help="可选单字词库，仅用于补充 token 宇宙；复现内置 169-token 方案时可省略")
    ap.add_argument("--jichu", type=Path, default=here / "jichu.dict.yaml",
                    help="三列词表：词<TAB>带调拼音<TAB>权重；优化只取二字词")
    ap.add_argument("--shadow-jichu", type=Path, default=None,
                    help="完整词库，仅做影子审计，不参与优化")
    ap.add_argument("--out", type=Path, default=here / "V12_balanced_global")
    ap.add_argument("--min-weight", type=float, default=0.0,
                    help="jichu 目标最低词频，默认 0=整份筛选后的 jichu")
    ap.add_argument("--neutral-policy", choices=("free", "distinct"), default="free")
    ap.add_argument("--max-per-key", type=int, default=8)
    ap.add_argument("--tie-policy", choices=("allow", "split"), default="allow")
    ap.add_argument("--priority-mode", choices=("lexicographic", "weighted"), default="lexicographic")
    ap.add_argument("--tier-thresholds", default="100000,30000,10000,4000,1000,0")
    ap.add_argument("--weight-scale", type=int, default=1000)
    ap.add_argument("--seconds-per-pass", type=float, default=1800.0)
    ap.add_argument("--handfeel-seconds", type=float, default=900.0,
                    help="每个物理键手感词典序目标最多求解秒数")
    ap.add_argument("--balance-seconds", type=float, default=600.0,
                    help="最大桶负载/最终负载均衡目标每层最多求解秒数；默认 600")
    ap.add_argument("--bucket-max-slack", type=float, default=0.05,
                    help="最大实体键总负载最优值允许上浮比例，给后续手感优化留自由度；默认 0.05")
    ap.add_argument("--cold-keys", default="q,p", help="高频 token 避开的实体键，逗号分隔；默认 q,p")
    ap.add_argument("--critical-top", type=int, default=20, help="加权使用量前 N 个 token 避开冷键；默认 20，0=不保护")
    ap.add_argument("--critical-mass", type=float, default=None,
                    help="改用绝对加权使用量阈值（覆盖 --critical-top）；只统计当前 jichu")
    ap.add_argument("--heat-slack", type=float, default=0.02,
                    help="允许热区目标值上浮比例，用于后续手感优化；默认 0.02，0=严格热区优先")
    ap.add_argument("--initial-layout", type=Path, default=None,
                    help="旧结果目录、tone_final_to_key.tsv 或 checkpoint JSON；全算时作为可行起点")
    ap.add_argument("--layout-only", action="store_true",
                    help="须指定 --initial-layout；只重排实体键，不重建/求解首选冲突矩阵")
    ap.add_argument("--global-sec", type=float, default=86400.0)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--no-handfeel", action="store_true",
                    help="关闭首选锁定后的手感/热区优化")
    ap.add_argument("--decision-file", type=Path, default=None,
                    help="可选 TSV：text/pinyin/decision，支持 AUTO、FORCE_FIRST、SACRIFICE_TARGET")
    ap.add_argument("--algebra-template", type=Path, default=None,
                    help="可选紧凑转写模板，必须有独占的 {{TOKEN_KEY_RULES}} 占位符")
    ap.add_argument("--skip-algebra-check", action="store_true")
    ap.add_argument("--matrix-only", action="store_true", help="只生成读音展开矩阵和冲突矩阵")
    args = ap.parse_args()
    args.cold_key_set = parse_key_set(args.cold_keys)
    if args.critical_top < 0: ap.error("--critical-top 必须 >=0")
    if args.critical_mass is not None and (not math.isfinite(args.critical_mass) or args.critical_mass <= 0):
        ap.error("--critical-mass 必须为正有限数；关闭保护请用 --critical-top 0")
    if not math.isfinite(args.heat_slack) or not 0 <= args.heat_slack <= 1: ap.error("--heat-slack 必须在 0..1")
    if not math.isfinite(args.bucket_max_slack) or not 0 <= args.bucket_max_slack <= 1:
        ap.error("--bucket-max-slack 必须在 0..1")
    if any(not math.isfinite(x) or x <= 0 for x in (args.global_sec, args.seconds_per_pass, args.handfeel_seconds, args.balance_seconds)):
        ap.error("求解时间必须为正有限数")
    if args.workers <= 0: ap.error("--workers 必须为正整数")
    if args.layout_only and args.initial_layout is None: ap.error("--layout-only 需要 --initial-layout")
    if args.layout_only and (args.no_handfeel or args.matrix_only): ap.error("--layout-only 不能和 --no-handfeel/--matrix-only 同用")
    if args.max_per_key <= 0 or args.max_per_key > 26: raise SystemExit("--max-per-key 必须在 1..26")
    if args.weight_scale <= 0: raise SystemExit("--weight-scale 必须为正整数")
    if not args.jichu.is_file():
        raise SystemExit(f"找不到 jichu：{args.jichu}")
    if args.zi is not None and not args.zi.is_file():
        raise SystemExit(f"找不到 zi：{args.zi}")
    if args.initial_layout and not args.initial_layout.exists(): raise SystemExit(f"找不到旧布局：{args.initial_layout}")
    if args.algebra_template and not args.algebra_template.is_file(): raise SystemExit(f"找不到转写模板：{args.algebra_template}")
    args.out.mkdir(parents=True, exist_ok=True)

    chars, zi_stats, zi_bad = (read_words(args.zi) if args.zi else ([], {"optional": True}, []))
    all_jichu, jichu_stats, jichu_bad = read_words(args.jichu)
    all_jichu = deduplicate(all_jichu)
    words = [w for w in all_jichu if len(w.text) == 2 and w.weight >= args.min_weight]
    if not words:
        raise SystemExit("jichu 没有可参与的二字词")

    targets = source_first(words)
    observed_tokens = {s.token for w in chars + words for s in w.syls}
    tokens = sorted(set(DEFAULT_TOKEN_UNIVERSE) | observed_tokens)
    _, weighted_token_mass = handfeel_usage(words)
    hard_edges = tone_edges(tokens, args.neutral_policy)
    force_first, sacrificed = read_decisions(args.decision_file, targets) if args.decision_file else (set(), set())
    loaded_mapping = None
    if args.initial_layout:
        old = load_mapping(args.initial_layout)
        missing = set(tokens) - set(old)
        if missing: raise SystemExit(f"旧布局缺 {len(missing)} 个 token：{', '.join(sorted(missing))}；请先运行全算模式")
        loaded_mapping = {t: old[t] for t in tokens}
        validate_mapping(loaded_mapping, tokens, hard_edges, args.max_per_key)
    if args.layout_only:
        started = time.time()
        before = audit(words, targets, loaded_mapping, args.tie_policy)
        if any(before[i]['loss'] for i in force_first):
            raise SystemExit("旧布局尚未满足 FORCE_FIRST；整桶重排无法修复首选，请使用全算模式")
        try:
            mapping, logs, completed, reason = optimize_physical_keys(loaded_mapping, words, args, started)
        except Exception as exc:
            mapping = dict(loaded_mapping)
            logs = []
            completed = 0
            reason = f"FALLBACK:{type(exc).__name__}:{exc}"
            print(f"[handfeel] WARNING：layout-only 手感优化失败；原布局保持不变并继续导出：{exc}", flush=True)
        after = audit(words, targets, mapping, args.tie_policy)
        if any((before[i]['status'], before[i]['loss'], before[i]['candidate_count']) !=
               (after[i]['status'], after[i]['loss'], after[i]['candidate_count']) for i in before):
            raise RuntimeError("重排前后逐词首选关系不一致，拒绝导出")
        meta = {"jichu_rows": len(words), "source_first_targets": len(targets), "tokens": len(tokens),
                "neutral_policy": args.neutral_policy, "tie_policy": args.tie_policy,
                "solver": "CP-SAT_PHYSICAL_REMAP_ONLY", "proof_status": "NOT_REOPTIMIZED_PRIORITY",
                "solver_status": ("LAYOUT_ONLY_RELATIONS_VERIFIED" if completed else "LAYOUT_ONLY_BASE_PRESERVED"),
                "priority_attempted": False, "priority_complete": False,
                "handfeel_stage_logs": logs, "handfeel_stages_completed": completed,
                "handfeel_stages_total": len(HandfeelBucketCpSat.NAMES), "handfeel_stop_reason": reason,
                "layout_source": str(args.initial_layout), "elapsed_sec": time.time() - started}
        _, final_meta = export_outputs(args.out, mapping, words, targets, hard_edges, args.max_per_key,
                                       meta, args, chars, force_first, sacrificed,
                                       handfeel_applied=(mapping != loaded_mapping))
        if args.shadow_jichu:
            if not args.shadow_jichu.is_file(): raise SystemExit(f"找不到影子词库：{args.shadow_jichu}")
            shadow, _, _ = read_words(args.shadow_jichu)
            write_shadow_audit(args.out / "shadow_target_audit.tsv", shadow, mapping, targets, args.tie_policy)
        print(f"V12 物理键重排完成：{args.out}；首选关系逐词验证不变", flush=True)
        print(f"retained={final_meta['actual_retained']:,} secondary={final_meta['actual_secondary']:,} tied={final_meta['actual_tied']:,}", flush=True)
        return
    clauses, forced, conflict_stats = compile_conflicts(words, targets, hard_edges, args.tie_policy, args.out)
    impossible_force = sorted(set(force_first) & set(forced))
    if impossible_force:
        by_id = {w.idx: w for w in targets}
        examples = "；".join(f"{by_id[i].text}/{by_id[i].pinyin} <- {forced[i][0].text}/{forced[i][0].pinyin}" for i in impossible_force[:10])
        raise RuntimeError("FORCE_FIRST 与完全相同编码结构冲突，无法硬保护：" + examples)
    matrix_meta = {
        "jichu_rows": len(words), "source_first_targets": len(targets), "tokens": len(tokens),
        "capacity": args.max_per_key * 26, "tone_edges": len(hard_edges),
        "tie_policy": args.tie_policy, "neutral_policy": args.neutral_policy,
        "forced_unavoidable_targets": len(forced), "manual_force_count": len(force_first),
        "manual_sacrifice_count": len(sacrificed), "zi_stats": zi_stats, "jichu_stats": jichu_stats,
        "parse_bad_examples": {"zi": zi_bad, "jichu": jichu_bad},
        "version": VERSION,
        "input_sha256": {"jichu": file_sha256(args.jichu), "zi": file_sha256(args.zi)},
        **conflict_stats,
    }
    write_tsv(args.out / "expanded_reading_matrix.tsv",
              ["text", "pinyin", "weight", "initial_keys", "tokens", "source_group"],
              ([w.text, w.pinyin, w.weight, " ".join(w.ikeys), " ".join(w.tokens), "|".join(w.group)]
               for w in sorted(targets, key=lambda z: (-z.weight, z.text, z.pinyin))))
    dup = defaultdict(list)
    for w in words: dup[w.group].append(w)
    write_tsv(args.out / "same_reading_duplicates.tsv", ["group", "text", "pinyin", "weight"],
              (["|".join(g), w.text, w.pinyin, w.weight] for g, arr in dup.items() if len(arr) > 1 for w in arr))
    atomic_json(args.out / "v12_matrix_summary.json", matrix_meta)
    print(f"V12 全局矩阵：jichu={len(words):,} targets={len(targets):,} tokens={len(tokens)}", flush=True)
    print(f"soft_clauses={conflict_stats['soft_clauses']:,} inherent_losses={conflict_stats['inherent_losses']:,} tone_edges={len(hard_edges):,}", flush=True)
    if args.matrix_only:
        print(f"矩阵输出：{args.out}", flush=True); return

    # 首选模型使用抽象键桶，消除物理键排列对称性。
    model = GlobalCpSat(tokens, hard_edges, clauses, forced, force_first, args.max_per_key)
    initial = loaded_mapping or initial_mapping(tokens, hard_edges, args.max_per_key, 17)
    if initial:
        initial = canonicalize(initial, tokens)
        initial_audit = audit(words, targets, initial, args.tie_policy)
        model.apply_hint(initial, initial_audit)
        print(f"[init] greedy feasibility hint max_load={max(Counter(initial.values()).values())} loss={sum(int(r["loss"]) for r in initial_audit.values())}", flush=True)
    started = time.time(); current = None; stage_logs = []; all_optimal = True
    stage_stop_reason = ""
    stages = priority_stages(args, targets, sacrificed, model.loss)

    # V12：首选阶段每走一步都把“当前最好可行布局”落盘。
    # 后续即使超时、断电，或手感阶段失败，也不会把数小时结果一起丢掉。
    def save_priority_checkpoint(note):
        if current is not None:
            mp = canonicalize(model.mapping_from(current), tokens)
        elif initial is not None:
            mp = dict(initial)
        else:
            return
        validate_mapping(mp, tokens, hard_edges, args.max_per_key)
        atomic_json(
            args.out / "v12_priority_checkpoint.json",
            {
                "mapping": mp,
                "note": note,
                "stages": stage_logs,
                "elapsed_sec": time.time() - started,
            },
        )

    save_priority_checkpoint("INITIAL_FEASIBLE")
    # 如果用户提供了旧布局，它就是当前词库上的已验证可行基线。
    # 每个首选层都加一条“不得差于基线”的硬上界，避免 CP-SAT 在
    # UNKNOWN 后返回一个新的、但全局更差的 FEASIBLE 布局，造成删词
    # 后次选数量反而增加。新布局仍可在任何层严格优于基线。
    baseline_bounds = {}
    if loaded_mapping is not None:
        baseline_mapping = canonicalize(loaded_mapping, tokens)
        baseline_audit = audit(words, targets, baseline_mapping, args.tie_policy)
        for label, coeff in stages:
            bound = objective_cost(coeff, baseline_audit)
            expr0 = sum(int(c) * model.loss[i] for i, c in coeff.items())
            model.model.add(expr0 <= int(bound))
            baseline_bounds[label] = int(bound)
        print(f"[baseline-guard] 已锁定旧布局各优先层上界：{len(baseline_bounds)} 层；新解不得退化", flush=True)
    for label, coeff in stages:
        remaining = args.global_sec - (time.time() - started)
        if remaining <= 0:
            all_optimal = False
            stage_stop_reason = "GLOBAL_TIME_LIMIT"
            print(f"[stage] {label}: SKIPPED_GLOBAL_TIME_LIMIT; 不再伪造结果", flush=True)
            break
        expr = sum(int(c) * model.loss[i] for i, c in coeff.items())
        seconds = min(args.seconds_per_pass, max(1.0, remaining))
        solver, status, status_name, value = model.solve_pass(
            [(model.loss[i], c) for i, c in coeff.items()], seconds, args.workers)
        stage_logs.append({"stage": label, "status": status_name, "objective": value,
                           "variables": len(coeff), "seconds": seconds})
        print(f"[stage] {label}: {status_name} objective={value}", flush=True)
        if status in (model.cp.OPTIMAL, model.cp.FEASIBLE):
            # CP-SAT 返回的 FEASIBLE 解不一定优于已有可行解；尤其在
            # 低频层超时后，不能让一个较差的新解覆盖 V9/初始布局。
            candidate_mapping = canonicalize(model.mapping_from(solver), tokens)
            candidate_audit = audit(words, targets, candidate_mapping, args.tie_policy)
            candidate_value = objective_cost(coeff, candidate_audit)
            incumbent_mapping = None
            if current is not None:
                incumbent_mapping = canonicalize(model.mapping_from(current), tokens)
            elif initial is not None:
                incumbent_mapping = initial
            incumbent_value = (objective_cost(coeff, audit(words, targets, incumbent_mapping, args.tie_policy))
                               if incumbent_mapping is not None else None)
            accepted_value = candidate_value
            if incumbent_value is not None and candidate_value > incumbent_value:
                accepted_value = incumbent_value
                print(f"[stage] {label}: 新解 objective={candidate_value} 劣于已有上界={incumbent_value}，拒绝覆盖", flush=True)
            else:
                current = solver
            if status != model.cp.OPTIMAL:
                all_optimal = False
            model.model.add(expr <= int(accepted_value))
            stage_logs[-1].update({"candidate_audit_objective": candidate_value,
                                   "accepted_objective": accepted_value,
                                   "incumbent_objective": incumbent_value})
            save_priority_checkpoint(f"AFTER_{label}_{status_name}")
            # 下一层继续使用当前最好布局作完整 hint，避免每一层都从最初 greedy 起点重搜。
            best_hint = (canonicalize(model.mapping_from(current), tokens)
                         if current is not None else initial)
            if best_hint is not None:
                model.apply_hint(best_hint, audit(words, targets, best_hint, args.tie_policy))
            continue

        # UNKNOWN/INFEASIBLE 不再中断整个流程。用当前已知可行布局作为
        # 这一层的保守上界，禁止后续层把这一层变得更差，然后继续尝试。
        all_optimal = False
        stage_stop_reason = f"{label}:{status_name}"
        incumbent_mapping = None
        if current is not None:
            incumbent_mapping = canonicalize(model.mapping_from(current), tokens)
        elif initial is not None:
            incumbent_mapping = initial
        if incumbent_mapping is not None:
            incumbent_audit = audit(words, targets, incumbent_mapping, args.tie_policy)
            incumbent_value = objective_cost(coeff, incumbent_audit)
            model.model.add(expr <= int(incumbent_value))
            print(f"[stage] {label}: 未返回新解；保留当前可行上界={incumbent_value}，继续下一层", flush=True)
        else:
            print(f"[stage] {label}: 无当前可行布局；继续尝试下一层", flush=True)
        save_priority_checkpoint(f"AFTER_{label}_{status_name}")
        best_hint = (canonicalize(model.mapping_from(current), tokens)
                     if current is not None else initial)
        if best_hint is not None:
            model.apply_hint(best_hint, audit(words, targets, best_hint, args.tie_policy))

    priority_attempted = (len(stage_logs) == len(stages))
    priority_complete = (priority_attempted
                         and all(x["status"] in ("OPTIMAL", "FEASIBLE") for x in stage_logs))
    primary_solver_found = current is not None
    if current is not None:
        primary_final_mapping = canonicalize(model.mapping_from(current), tokens)
    elif initial is not None:
        primary_final_mapping = canonicalize(initial, tokens)
    else:
        primary_final_mapping = None
    loss_variable_count = len(model.loss)
    # 第二阶段：锁死各词频层首选上界，再开放“桶成员 + 真实物理键”联合细化。
    # 因此可以利用同优解改善负载和手感，但不能让任何已锁定优先层退化。
    global_refine_logs = []
    global_refine_mapping = None
    global_refine_completed = 0
    global_refine_total = 0
    global_refine_stop_reason = ""
    global_refine_priority_bounds = {}
    balance_before_refine = {}
    balance_after_refine = {}

    # 固定桶手感模型仅作为联合细化异常时的兜底。
    handfeel_logs = []
    handfeel_mapping = None
    handfeel_completed = 0
    handfeel_stop_reason = ""

    base_solver_mapping = primary_final_mapping if priority_attempted else None

    # 第一模型完成后立即释放，避免第二模型建立时内存近似翻倍。
    try:
        del save_priority_checkpoint
    except NameError:
        pass
    current = None
    solver = None
    initial_audit = None
    baseline_audit = None
    incumbent_audit = None
    candidate_audit = None
    del model
    gc.collect()

    if not args.no_handfeel and priority_attempted and base_solver_mapping is not None:
        if not priority_complete:
            print("[refine] 首选层已全部尝试但存在 UNKNOWN/未证最优；以当前各层可行上界作为硬保护进入联合优化", flush=True)
        try:
            (global_refine_mapping, global_refine_logs, global_refine_completed,
             global_refine_total, global_refine_stop_reason, global_refine_priority_bounds,
             balance_before_refine, balance_after_refine) = optimize_global_refinement(
                base_solver_mapping, tokens, words, targets, hard_edges, clauses, forced,
                force_first, stages, args, started)
            if (global_refine_completed < global_refine_total
                    or any(x["status"] != "OPTIMAL" for x in global_refine_logs)):
                all_optimal = False
            print(
                f"[refine] 联合优化完成 {global_refine_completed}/{global_refine_total} 层；"
                f"max_total_load {balance_before_refine.get('max_total_load', 0)} -> {balance_after_refine.get('max_total_load', 0)}；"
                f"total_CV {balance_before_refine.get('total_load_cv', 0):.4f} -> {balance_after_refine.get('total_load_cv', 0):.4f}",
                flush=True,
            )
        except Exception as exc:
            all_optimal = False
            global_refine_stop_reason = f"FALLBACK:{type(exc).__name__}:{exc}"
            print(f"[refine] WARNING：联合优化异常，自动退回固定桶物理重排：{exc}", flush=True)
            try:
                handfeel_mapping, handfeel_logs, handfeel_completed, handfeel_stop_reason = optimize_physical_keys(
                    base_solver_mapping, words, args, started)
                print(f"[handfeel-fallback] 已完成 {handfeel_completed}/{len(HandfeelBucketCpSat.NAMES)} 层", flush=True)
            except Exception as exc2:
                handfeel_mapping = None
                handfeel_logs = []
                handfeel_completed = 0
                handfeel_stop_reason = f"FALLBACK:{type(exc2).__name__}:{exc2}"
                print(f"[handfeel-fallback] WARNING：固定桶手感也失败；保留首选布局继续导出：{exc2}", flush=True)
    elif not args.no_handfeel and not priority_attempted:
        all_optimal = False
        print("[refine] SKIP：全局时间已耗尽，首选层没有全部尝试；直接保留当前最好首选布局", flush=True)
    fallback = False
    solver_status = stage_logs[-1]["status"] if stage_logs else "UNKNOWN"
    if global_refine_mapping is not None:
        solver_status = ("GLOBAL_REFINEMENT_PARTIAL"
                         if global_refine_completed < global_refine_total
                         else "GLOBAL_REFINEMENT_COMPLETE")
    elif handfeel_logs:
        solver_status = ("FEASIBLE_HAND_FEEL_FALLBACK_PARTIAL"
                         if handfeel_completed < len(HandfeelBucketCpSat.NAMES)
                         else "FEASIBLE_HAND_FEEL_FALLBACK")
    if not priority_complete and primary_solver_found:
        solver_status = ("PRIORITY_INCOMPLETE_GLOBAL_REFINED"
                         if global_refine_mapping is not None else
                         ("PRIORITY_INCOMPLETE_HAND_FEEL_FALLBACK" if handfeel_logs
                          else "PRIORITY_INCOMPLETE_FROM_LAST_STAGE"))
    if primary_solver_found and solver_status == "UNKNOWN":
        solver_status = "FEASIBLE_FROM_LAST_STAGE"
    if primary_final_mapping is None:
        raise RuntimeError(f"CP-SAT 无可用布局，且没有可行初始布局：{solver_status}")
    if not primary_solver_found:
        fallback = True
        all_optimal = False
        if global_refine_mapping is None and handfeel_mapping is None:
            solver_status = "HEURISTIC_FALLBACK"
    mapping = global_refine_mapping or handfeel_mapping or primary_final_mapping
    validate_mapping(mapping, tokens, hard_edges, args.max_per_key)
    # 导出时重新按最终真实编码审计，并生成紧凑 algebra。
    meta = dict(matrix_meta, solver="CP-SAT_V12_BALANCED_GLOBAL", proof_status=("OPTIMAL" if all_optimal else ("HEURISTIC_FALLBACK" if fallback else "FEASIBLE")),
                stage_logs=stage_logs, handfeel_stage_logs=handfeel_logs,
                global_refine_stage_logs=global_refine_logs,
                priority_complete=priority_complete,
                priority_attempted=priority_attempted,
                priority_stages_completed=len(stage_logs),
                priority_stages_total=len(stages),
                priority_stop_reason=stage_stop_reason,
                handfeel_stages_completed=handfeel_completed,
                handfeel_stages_total=(len(HandfeelBucketCpSat.NAMES) if handfeel_logs else 0),
                handfeel_stop_reason=handfeel_stop_reason,
                global_refine_stages_completed=global_refine_completed,
                global_refine_stages_total=global_refine_total,
                global_refine_stop_reason=global_refine_stop_reason,
                global_refine_priority_bounds=global_refine_priority_bounds,
                bucket_balance_before_refine=balance_before_refine,
                bucket_balance_after_refine=balance_after_refine,
                elapsed_sec=time.time() - started, solver_status=solver_status,
                loss_variables=loss_variable_count, critical_top=args.critical_top,
                critical_mass=args.critical_mass, cold_keys=sorted(args.cold_key_set),
                heat_slack=args.heat_slack, bucket_max_slack=args.bucket_max_slack,
                balance_seconds=args.balance_seconds,
                baseline_guard=bool(baseline_bounds), baseline_bounds=baseline_bounds,
                initial_layout=str(args.initial_layout) if args.initial_layout else "")
    rows, final_meta = export_outputs(args.out, mapping, words, targets, hard_edges, args.max_per_key,
                                       meta, args, chars, force_first, sacrificed,
                                       handfeel_applied=bool(global_refine_mapping or handfeel_mapping))
    if args.shadow_jichu and args.shadow_jichu.is_file():
        shadow, _, _ = read_words(args.shadow_jichu)
        write_shadow_audit(args.out / "shadow_target_audit.tsv", shadow, mapping, targets, args.tie_policy)
    else:
        print("[shadow] 未提供 shadow-jichu；低权重原词库未参与优化。", flush=True)
    final_meta.update({"stage_logs": stage_logs, "solver_status": solver_status, "fallback": fallback,
                       "priority_attempted": priority_attempted,
                       "priority_stop_reason": stage_stop_reason,
                       "handfeel_stages_completed": handfeel_completed,
                       "handfeel_stages_total": (len(HandfeelBucketCpSat.NAMES) if handfeel_logs else 0),
                       "handfeel_stop_reason": handfeel_stop_reason,
                       "global_refine_stage_logs": global_refine_logs,
                       "global_refine_stages_completed": global_refine_completed,
                       "global_refine_stages_total": global_refine_total,
                       "global_refine_stop_reason": global_refine_stop_reason,
                       "global_refine_priority_bounds": global_refine_priority_bounds,
                       "bucket_balance_before_refine": balance_before_refine,
                       "bucket_balance_after_refine": balance_after_refine})
    atomic_json(args.out / "v12_solver_summary.json", final_meta)
    print(f"V12 全局布局完成：{args.out}", flush=True)
    print(f"status={solver_status} actual_retained={final_meta['actual_retained']:,} actual_secondary={final_meta['actual_secondary']:,} actual_tied={final_meta['actual_tied']:,}", flush=True)


if __name__ == "__main__":
    main()
